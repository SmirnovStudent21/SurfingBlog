﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SurfClub.Models.DbModels;


namespace SurfClub.Models
{
    public class SurfClubDbContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Post> Posts { get; set; }
        public SurfClubDbContext(DbContextOptions options) : base(options)
        {
            Database.EnsureCreated();       //The seed entity for entity type 'User' cannot be added because no value was provided for the required property 'Surname'.
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().HasData(
                new User { Id = 1,
                    Nickname = "Testuser",
                    Password = "TestPassword",
                  //  PassConf = "TestPassword",
                    Email = "test@test.com",
                    Surname = "Valov",
                           Photo = new Guid("498d7e21-cb9b-43a6-9e5b-37fcb41e273f")
                }) ;
        }
        
    }
}
